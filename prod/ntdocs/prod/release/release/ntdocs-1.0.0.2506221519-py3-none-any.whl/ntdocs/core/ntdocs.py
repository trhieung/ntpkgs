from typing import Dict
from pathlib import Path

class NTDocs:
    def __init__(self, pkg_name: str, save_dir: Path):
        self.pkg_name = pkg_name
        self.docs_dir = save_dir / "documentations"
        self.templates: Dict[str, Dict[str, str]] = {}

        self.template_setup()

    def template_setup(self):
        """Set up default technical documentation template."""
        technical = {
            "index.md": "# Overview\n\nThis package provides tools for...",
            "installation.md": "# Installation\n\n```bash\npip install yourlib\n```",
            "usage.md": "# Usage\n\nExample usage patterns for the main functions.",
            "changelog.md": "# Changelog\n\n- v0.1.0: Initial release",
            "release.md": ""
        }

        self.template_add(name="technical", tree=technical)

    def template_add(self, name: str, tree: Dict[str, str]):
        """Add a new documentation template under a named category."""
        self.templates[name] = tree

    def templates_build(self):
        """Generate the documentation files from templates."""
        for section, files in self.templates.items():
            section_dir = self.docs_dir / section
            section_dir.mkdir(parents=True, exist_ok=True)

            for filename, content in files.items():
                file_path = section_dir / filename
                file_path.write_text(content, encoding="utf-8")
