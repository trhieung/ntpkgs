import importlib
import inspect
from typing import Dict
from pathlib import Path
import types


class NTDocs:
    def __init__(self, pkg_name: str, save_dir: Path):
        self.pkg_name = pkg_name
        self.docs_dir = save_dir / "documentations"
        self.templates: Dict[str, Dict[str, str]] = {}

        self.template_setup()

    def template_setup(self):
        """Set up default technical documentation template."""
        technical = {
            "index.md": "# Overview\n\nThis package provides tools for...",
            "installation.md": "# Installation\n\n```bash\npip install yourlib\n```",
            "usage.md": "# Usage\n\nExample usage patterns for the main functions.",
            "changelog.md": "# Changelog\n\n- v0.1.0: Initial release",
            "release.md": ""
        }

        self.template_add(name="technical", tree=technical)

    def template_add(self, name: str, tree: Dict[str, str]):
        """Add a new documentation template under a named category."""
        self.templates[name] = tree

    def templates_build(self):
        """Generate the documentation files from templates."""
        for section, files in self.templates.items():
            section_dir = self.docs_dir / section
            section_dir.mkdir(parents=True, exist_ok=True)

            for filename, content in files.items():
                file_path = section_dir / filename
                file_path.write_text(content, encoding="utf-8")

    def modules_build(self):
        """Extract public classes/functions from modules in __all__ and write docs."""
        print("hihihihihi")
        try:
            top_module = importlib.import_module(self.pkg_name)
        except ImportError as e:
            print(f"Error importing {self.pkg_name}: {e}")
            return

        if not hasattr(top_module, "__all__"):
            print(f"Module {self.pkg_name} has no __all__ attribute.")
            return

        modules: Dict[str, Dict[str, str]] = {}

        for subname in top_module.__all__:
            try:
                full_module_name = f"{self.pkg_name}.{subname}"
                submodule = importlib.import_module(full_module_name)
            except ImportError:
                continue

            public_members = {}

            for name, obj in inspect.getmembers(submodule):
                if name.startswith("_"):
                    continue
                if inspect.isfunction(obj) or inspect.isclass(obj):
                    doc = inspect.getdoc(obj) or "*No docstring provided.*"
                    public_members[name] = doc

            if public_members:
                modules[subname] = public_members

        # Generate Markdown files
        module_docs_dir = self.docs_dir / "modules"
        module_docs_dir.mkdir(parents=True, exist_ok=True)

        for modname, contents in modules.items():
            doc_lines = [f"# Module `{modname}`\n"]
            for symbol, docstring in contents.items():
                doc_lines.append(f"## `{symbol}`\n\n{docstring}\n")
            doc_text = "\n".join(doc_lines)

            doc_path = module_docs_dir / f"{modname}.md"
            doc_path.write_text(doc_text, encoding="utf-8")
