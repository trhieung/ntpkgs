
from dataclasses import dataclass

@dataclass
class XModel:
    x:int