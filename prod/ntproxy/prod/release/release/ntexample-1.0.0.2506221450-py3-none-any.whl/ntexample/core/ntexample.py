

class NTExample:
    def __init__(self, nt):
        self.nt=nt

    def intro(self):
        """_summary_: intro only
        """
        print("Hi from intro!", self.nt)